# GPS Server for Teltonika trackers

## Tracker configuration

Go to GPRS settings: https://wiki.teltonika-gps.com/view/FMC880_GPRS_settings

- Server settings
  - Domain = your server IP/Domain 
  - Port = server port (12050 by default)
  - Protocol = TCP

- Record settings
  - ACK Type = TCP/IP

## Useful links
- https://wiki.teltonika-gps.com/view/FMC880_Teltonika_Data_Sending_Parameters_ID